// CodeAlpha IoT Task 3: IoT Prototype (simulation)
// Project: PIR motion detection alarm
// PIR OUT -> D2; active buzzer + -> D8; buzzer - -> GND.

const int pirPin = 2;
const int buzzerPin = 8;

void setup() {
  pinMode(pirPin, INPUT);
  pinMode(buzzerPin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int motionDetected = digitalRead(pirPin);

  if (motionDetected == HIGH) {
    tone(buzzerPin, 1000); // Alarm tone when motion is detected
    Serial.println("Motion detected! Alarm ON");
  } else {
    noTone(buzzerPin);
    Serial.println("No motion. Alarm OFF");
  }

  delay(200);
}
